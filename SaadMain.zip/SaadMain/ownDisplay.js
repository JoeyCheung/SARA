$(document).ready(function() {
      function pr() {
        document.getElementById("result").innerHTML = document.getElementById('search').value; 

      }

    };